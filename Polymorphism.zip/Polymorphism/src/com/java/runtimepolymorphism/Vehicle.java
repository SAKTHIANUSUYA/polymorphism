package com.java.runtimepolymorphism;

public class Vehicle {
	public static void main(String[] args) {
//		Car c = new Car();
//		c.rentPerDay();
		Vehicle v = new Car();
		Car c = (Car)v;
		c.rentPerDay();
//		v.rentPerDay();
	}
	void rentPerDay() {
		System.out.println("1000");
	}
}
class Car extends Vehicle{
	@Override
	void rentPerDay() {
		System.out.println("7000");
	}
}
