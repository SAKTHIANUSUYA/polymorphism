package com.java.polymorphism;
/*both class and method should be abstract
 * abstract method must be declared but not defined this should be a incomplete class*/
public abstract class Example {
	abstract void abstractmethod();

}
