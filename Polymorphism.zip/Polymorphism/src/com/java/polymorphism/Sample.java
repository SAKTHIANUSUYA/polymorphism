package com.java.polymorphism;
/*This is a Concerete class with method declaration and definition/implementation */
public class Sample extends Example{
	@Override 
	void abstractmethod() {
		System.out.println("implementation for abstract method");
	}

}
