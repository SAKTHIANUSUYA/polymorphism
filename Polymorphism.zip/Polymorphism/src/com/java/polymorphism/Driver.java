package com.java.polymorphism;

public class Driver  {
	public static void main(String[] args) {
		// Example e = new Example();// Abstract Class can't be instantiated
		Sample s = new Sample();
		s.abstractmethod();
	}
}
