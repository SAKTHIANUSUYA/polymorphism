package com.java.methodoverloading;

public class Employee {
	public static void main(String[] args) {
		Employee e = new Employee();
		e.salary(40000);
		e.salary(40000,5000);
		e.salary(40000,5000,2000);
		
	}
	void salary(int amount){
		System.out.println("Salary credited "+amount);
	}
	void salary(int amount,int allowance) {
		System.out.println("Salary credited "+(amount+allowance));
	}
	void salary(int amount,int allowance,int deduction) {
		System.out.println("Salary credited "+(amount+allowance-deduction));
	}

}
