package com.java.methodoverriding;

public class Bank {
	public double rateofIntrest() {
		return 0.0;
	}
	public static void main(String[] args) {
		Bank b = new Bank();
		double roi = b.rateofIntrest();
		System.out.println(roi);
		SBI sbi = new SBI();
		roi = sbi.rateofIntrest();
		System.out.println(roi);
		HDFC hdfc = new HDFC();
		roi = hdfc.rateofIntrest();
		System.out.println(roi);
		ICIC icic = new ICIC();
		roi = icic.rateofIntrest();
		System.out.println(roi);
	}

}
class SBI extends Bank{
	@Override
	public double rateofIntrest() {
		return 2.5;
	}
}
class HDFC extends Bank{
	@Override
	public double rateofIntrest() {
		return 4.25;
	}
}
class ICIC extends Bank{
	@Override
	public double rateofIntrest() {
		return 5.01;
	}
}
