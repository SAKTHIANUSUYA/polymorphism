package com.java.methodoverriding;

public class Vehicle {
	void start() {
		System.out.println("Starting the Vehicle");
	}
	public static void main(String[] args) {
		Vehicle v = new Car();
		v.start();
	}

}
class Car extends Vehicle{
	@Override
	 void start() {
		System.out.println("Starting the Car");
	}
}
